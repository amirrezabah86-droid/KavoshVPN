package com.kavosh.vpn

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

data class VpnServer(
    val name: String,
    val address: String,
    val port: Int,
    val configUrl: String
)

class MainActivity : AppCompatActivity() {

    private var isConnected = false
    private lateinit var btnConnect: MaterialButton
    private lateinit var tvStatus: TextView
    private lateinit var serverSpinner: Spinner

    // لیست سرورهای جهانی پیش‌فرض + قابلیت دریافت خودکار آنلاین
    private val serverList = mutableListOf(
        VpnServer("🇩🇪 آلمان - فرانکفورت (VIP ثابت)", "de.kavosh-vpn.ir", 443, "vless://uuid@de.kavosh-vpn.ir:443?security=reality#Kavosh-DE"),
        VpnServer("🇳🇱 هلند - آمستردام (پرسرعت)", "nl.kavosh-vpn.ir", 443, "vless://uuid@nl.kavosh-vpn.ir:443?security=reality#Kavosh-NL"),
        VpnServer("🇫🇮 فنلاند - هلسینکی (پینگ گیمینگ)", "fi.kavosh-vpn.ir", 443, "vless://uuid@fi.kavosh-vpn.ir:443?security=reality#Kavosh-FI"),
        VpnServer("🇬🇧 انگلیس - لندن (ترید و بانکی)", "uk.kavosh-vpn.ir", 443, "vless://uuid@uk.kavosh-vpn.ir:443?security=reality#Kavosh-UK"),
        VpnServer("🇺🇸 آمریکا - نیویورک (آی‌پی ثابت)", "us.kavosh-vpn.ir", 443, "vless://uuid@us.kavosh-vpn.ir:443?security=reality#Kavosh-US")
    )

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startKavoshVpn()
        } else {
            Toast.makeText(this, "برای اتصال، تایید مجوز VPN الزامی است.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnConnect = findViewById(R.id.btnConnect)
        tvStatus = findViewById(R.id.tvStatus)
        serverSpinner = findViewById(R.id.serverSpinner)

        setupServerSpinner()
        updateServersFromCloud()

        btnConnect.setOnClickListener {
            if (!isConnected) {
                val intent = VpnService.prepare(this)
                if (intent != null) {
                    vpnPermissionLauncher.launch(intent)
                } else {
                    startKavoshVpn()
                }
            } else {
                stopKavoshVpn()
            }
        }
    }

    private fun setupServerSpinner() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            serverList.map { it.name }
        )
        serverSpinner.adapter = adapter
    }

    private fun startKavoshVpn() {
        val selectedServer = serverList[serverSpinner.selectedItemPosition]
        val serviceIntent = Intent(this, KavoshVpnService::class.java).apply {
            action = "START_VPN"
            putExtra("SERVER_NAME", selectedServer.name)
            putExtra("CONFIG_URL", selectedServer.configUrl)
        }
        startService(serviceIntent)

        isConnected = true
        btnConnect.text = "قطع اتصال"
        btnConnect.setBackgroundColor(Color.parseColor("#00897B"))
        tvStatus.text = "متصل شد: ${selectedServer.name}"
        tvStatus.setTextColor(Color.parseColor("#4DB6AC"))
    }

    private fun stopKavoshVpn() {
        val serviceIntent = Intent(this, KavoshVpnService::class.java).apply {
            action = "STOP_VPN"
        }
        startService(serviceIntent)

        isConnected = false
        btnConnect.text = "اتصال"
        btnConnect.setBackgroundColor(Color.parseColor("#0277BD"))
        tvStatus.text = "وضعیت: قطع (آماده اتصال)"
        tvStatus.setTextColor(Color.parseColor("#B0BEC5"))
    }

    private fun updateServersFromCloud() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val client = OkHttpClient()
                // لینک سابسکریپشن ابری برای آپدیت خودکار سرورها بدون نیاز به آپدیت برنامه
                val request = Request.Builder()
                    .url("https://raw.githubusercontent.com/kavosh-network/vpn-servers/main/servers.json")
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@launch
                    val jsonArray = JSONArray(body)
                    val newServers = mutableListOf<VpnServer>()
                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        newServers.add(
                            VpnServer(
                                obj.getString("name"),
                                obj.getString("address"),
                                obj.getInt("port"),
                                obj.getString("configUrl")
                            )
                        )
                    }
                    if (newServers.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            serverList.clear()
                            serverList.addAll(newServers)
                            setupServerSpinner()
                        }
                    }
                }
            } catch (_: Exception) {
                // استفاده از لیست سرورهای داخلی در صورت عدم دسترسی
            }
        }
    }
}
