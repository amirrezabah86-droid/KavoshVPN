package com.kavosh.vpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class KavoshVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP_VPN") {
            stopVpn()
            return START_NOT_STICKY
        }
        val serverName = intent?.getStringExtra("SERVER_NAME") ?: "Kavosh VPN"
        startVpn(serverName)
        return START_STICKY
    }

    private fun startVpn(sessionName: String) {
        if (vpnInterface != null) return
        try {
            val builder = Builder()
                .setSession(sessionName)
                .setMtu(1500)
                .addAddress("10.8.0.2", 24)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0)
            vpnInterface = builder.establish()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopVpn() {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {}
        vpnInterface = null
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
